# LUNAR VISION

Futuristic lunar mission-planning dashboard prototype built with Next.js, React Three Fiber and Three.js.

## Requirements
- Node.js 18.17+ (Node 20 LTS recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## What's included
- Interactive 3D lunar sphere with orbit controls, zoom and rotation
- Simulated Sun and Earth visual elements
- Candidate landing-site selector
- Date and mission-duration controls
- Environmental metrics and mission screening panel
- Interactive local-time slider and play/pause
- Responsive mission-control dashboard

## Scientific limitations
This is a visual prototype. All site metrics, illumination, communication windows and celestial positions are demonstration values, not verified NASA/JPL ephemeris or LOLA calculations. Do not use for mission operations. Replace demo calculations and textures with validated datasets before scientific use.

## Next scientific integration steps
1. Fetch ephemerides from JPL Horizons for Sun, Earth and Moon.
2. Use LOLA digital elevation models to calculate terrain-aware local horizons.
3. Compute solar elevation and direct-to-Earth line of sight at selected coordinates and timestamps.
4. Validate outputs against trusted mission-planning references.
