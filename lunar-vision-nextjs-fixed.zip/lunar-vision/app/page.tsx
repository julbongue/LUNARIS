
"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars, Sphere, Html } from "@react-three/drei";
import * as THREE from "three";
import { Activity, Globe2, Radio, Sun, Satellite, Play, Pause, Crosshair, Layers, ChevronDown, Zap } from "lucide-react";

type Site = {name:string; region:string; lat:number; lon:number; sunlight:number; earth:number; power:number; comm:number};
const sites:Site[]=[
 {name:"Shackleton Rim",region:"South Pole · Candidate A",lat:-89.9,lon:0.0,sunlight:68,earth:82,power:76,comm:91},
 {name:" de Gerlache",region:"South Pole · Candidate B",lat:-88.5,lon:-45.2,sunlight:54,earth:71,power:63,comm:78},
 {name:"Malapert Massif",region:"South Pole · Candidate C",lat:-85.9,lon:0.4,sunlight:81,earth:88,power:87,comm:94},
 {name:"Nobile Crater",region:"South Pole · Candidate D",lat:-84.8,lon:53.2,sunlight:42,earth:64,power:49,comm:69}
];
function Moon(){const ref=useRef<THREE.Mesh>(null);const texture=useMemo(()=>{const c=document.createElement("canvas");c.width=1024;c.height=512;const ctx=c.getContext("2d")!;ctx.fillStyle="#85888b";ctx.fillRect(0,0,c.width,c.height);let seed=17;const rand=()=>{seed=(seed*9301+49297)%233280;return seed/233280};for(let i=0;i<16000;i++){const x=rand()*c.width,y=rand()*c.height,r=rand()*2.2;ctx.fillStyle=rand()>.5?"rgba(225,225,220,.10)":"rgba(25,29,34,.10)";ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}for(let i=0;i<260;i++){const x=rand()*c.width,y=rand()*c.height,r=3+rand()*22;const g=ctx.createRadialGradient(x-r*.2,y-r*.2,r*.12,x,y,r);g.addColorStop(0,"rgba(35,39,43,.40)");g.addColorStop(.68,"rgba(55,59,63,.18)");g.addColorStop(.86,"rgba(220,218,210,.28)");g.addColorStop(1,"rgba(40,44,48,.04)");ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t},[]);useFrame((_,d)=>{if(ref.current)ref.current.rotation.y+=d*.035});return <group><Sphere ref={ref} args={[1.55,128,128]}><meshStandardMaterial map={texture} color="#b5b5b2" roughness={1} metalness={0.01}/></Sphere><mesh position={[0,-1.52,0]}><sphereGeometry args={[.055,24,24]}/><meshBasicMaterial color="#62e5ed"/></mesh></group>}
function Celestial({sunAngle}:{sunAngle:number}){const sun=useMemo(()=>new THREE.Vector3(Math.cos(sunAngle)*4,1.2,Math.sin(sunAngle)*4),[sunAngle]);return <><ambientLight intensity={.18}/><directionalLight position={sun.toArray()} intensity={2.1} color="#ffe3ad"/><pointLight position={[-4,1,3]} intensity={.4} color="#5aa8d8"/><mesh position={sun.toArray()}><sphereGeometry args={[.16,24,24]}/><meshBasicMaterial color="#ffd27c"/></mesh><mesh position={[-3.7,1.1,-2.7]}><sphereGeometry args={[.24,32,32]}/><meshBasicMaterial color="#4e9dd2"/></mesh><mesh position={[-3.7,1.1,-2.7]}><sphereGeometry args={[.27,32,32]}/><meshBasicMaterial color="#5dc8e9" wireframe transparent opacity={.22}/></mesh></>}
function Metric({icon:Icon,label,value,sub,percent,gold=false,state}:{icon:any;label:string;value:string;sub:string;percent:number;gold?:boolean;state?:string}){return <div className="metric"><div className="metric-top"><span className="metric-name"><Icon size={12} style={{display:"inline",marginRight:7,verticalAlign:"-2px",color:gold?"#e8bc66":"#5bcddd"}}/>{label}</span>{state&&<span className="state">{state}</span>}</div><div className="metric-value">{value}</div><div className="metric-sub">{sub}</div><div className={"bar "+(gold?"gold":"")}><i style={{width:percent+"%"}}/></div></div>}
export default function Home(){
 const [siteIndex,setSiteIndex]=useState(0),[date,setDate]=useState("2026-11-14"),[hour,setHour]=useState(9),[playing,setPlaying]=useState(false),[layer,setLayer]=useState("All layers"),[tab,setTab]=useState("Overview");
 const site=sites[siteIndex];const solar=Math.max(4,Math.round(site.sunlight+18*Math.sin((hour-6)*Math.PI/12)));const earth=Math.max(0,Math.min(100,site.earth+Math.round(9*Math.cos((hour-3)*Math.PI/12))));
 useEffect(()=>{if(!playing)return;const t=setInterval(()=>setHour(h=>(h+1)%24),900);return()=>clearInterval(t)},[playing]);
 return <div className="app">
  <header className="topbar"><div className="brand"><div className="brandmark"><Globe2 size={18}/></div><div>LUNAR VISION<small>MISSION INTELLIGENCE SYSTEM</small></div></div>
   <nav className="nav">{["Overview","Lunar Explorer","Site Comparison","Mission Timeline","Data & Analytics"].map(n=><button key={n} className={tab===n?"active":""} onClick={()=>setTab(n)}>{n.toUpperCase()}</button>)}</nav>
   <div className="topright"><span className="status">SYSTEM ONLINE</span><span className="utc">UTC 18:54:00</span></div>
  </header>
  <main>
   <div className="heading"><div><div className="eyebrow">CLPS / SOUTH POLE EXPLORATION</div><h1>Mission environment overview</h1><p>Analyse illumination, terrain context and direct-to-Earth communication conditions.</p></div><div className="mission-tag">MISSION ID&nbsp; <b>LV-2026-SP01</b> &nbsp;·&nbsp; DEMO SIMULATION</div></div>
   <div className="layout">
    <aside className="panel side left"><div className="panel-title">MISSION CONFIGURATION <Crosshair size={13}/></div>
     <div className="field"><label>LANDING SITE</label><select value={siteIndex} onChange={e=>setSiteIndex(Number(e.target.value))}>{sites.map((s,i)=><option value={i} key={s.name}>{s.name}</option>)}</select></div>
     <div className="field"><label>SELECTED COORDINATES</label><div className="coords"><input readOnly value={`${site.lat}° S`}/><input readOnly value={`${Math.abs(site.lon)}° ${site.lon<0?"W":"E"}`}/></div></div>
     <div className="field"><label>LANDING DATE</label><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
     <div className="field"><label>MISSION DURATION</label><select defaultValue="14"><option value="7">7 Earth days</option><option value="14">14 Earth days</option><option value="28">28 Earth days</option></select></div>
     <div className="panel-title" style={{marginTop:22}}>CANDIDATE SITES <span>04 SITES</span></div>
     <div className="site-list">{sites.map((s,i)=><button key={s.name} className={"site "+(siteIndex===i?"active":"")} onClick={()=>setSiteIndex(i)}><span className="dot">●</span><strong>{s.name}</strong><small>{s.region}</small></button>)}</div>
    </aside>
    <section className="panel scene-panel">
     <div className="scene-head"><div>3D LUNAR SURFACE / <b>SOUTH POLAR REGION</b></div><div>LAT {site.lat}° &nbsp; LON {site.lon}°</div></div>
     <div className="scene-label"><b>◉ {site.name.toUpperCase()}</b>LANDING ZONE / DEMO</div>
     <Canvas id="moonCanvas" camera={{position:[0,1.2,5.5],fov:42}}><Stars radius={90} depth={50} count={1800} factor={3} saturation={0}/><Celestial sunAngle={hour/24*Math.PI*2}/><Moon/><OrbitControls enablePan={false} minDistance={2.6} maxDistance={9} enableDamping dampingFactor={.06}/></Canvas>
     <div className="scene-legend"><span className="legend"><i style={{background:"#e9bf68"}}/> SUN</span><span className="legend"><i style={{background:"#55bce7"}}/> EARTH</span><span className="legend"><i style={{background:"#62e5ed"}}/> LANDING SITE</span></div>
     <div className="scene-hint">DRAG TO ROTATE · SCROLL TO ZOOM</div><div className="scene-controls"><button onClick={()=>setLayer(layer==="All layers"?"Terrain only":"All layers")}><Layers size={12} style={{display:"inline",marginRight:5}}/>{layer}</button><button onClick={()=>setSiteIndex((siteIndex+1)%sites.length)}>NEXT SITE ↗</button></div>
    </section>
    <aside className="panel side right"><div className="panel-title">ENVIRONMENTAL INTELLIGENCE <Activity size={13}/></div>
     <Metric icon={Sun} label="SOLAR ELEVATION" value={`${(solar*.42-8).toFixed(1)}°`} sub="Local apparent elevation" percent={solar} gold/>
     <Metric icon={Zap} label="ILLUMINATION INDEX" value={`${solar}%`} sub="Estimated solar availability" percent={solar} gold/>
     <Metric icon={Radio} label="EARTH VISIBILITY" value={`${earth}%`} sub="Direct line-of-sight estimate" percent={earth} state={earth>55?"VISIBLE":"LIMITED"}/>
     <Metric icon={Satellite} label="COMMUNICATION WINDOW" value={`${Math.round(site.comm/10)}.2 h`} sub="Estimated per operational cycle" percent={site.comm}/>
     <Metric icon={Activity} label="POWER POTENTIAL" value={`${site.power}%`} sub="Relative solar generation index" percent={site.power} gold/>
     <div style={{marginTop:14,padding:"10px",background:"#101d29",borderRadius:5,border:"1px solid #253849"}}><div className="eyebrow" style={{fontSize:8}}>MISSION ASSESSMENT</div><div style={{fontSize:11,marginTop:7,color:"#dce9f1"}}>{site.power>75&&earth>75?"Favourable candidate conditions":"Further assessment recommended"}</div><div style={{fontSize:9,color:"#71869a",marginTop:5,lineHeight:1.5}}>Preliminary screening only. Terrain horizon and verified ephemeris data required.</div></div>
    </aside>
   </div>
   <div className="bottom-grid">
    <section className="panel timeline-panel"><div className="timeline-head"><h3>CELESTIAL CONDITIONS TIMELINE</h3><span>LOCAL SIMULATION TIME · {date}</span></div><div className="time-controls"><button className="play" onClick={()=>setPlaying(!playing)}>{playing?<Pause size={13}/>:<Play size={13}/>}</button><input type="range" min="0" max="23" value={hour} onChange={e=>setHour(Number(e.target.value))}/><span className="time-label">{String(hour).padStart(2,"0")}:00 LST</span></div><div className="timeline-track"><span/><span/><span/><span/></div><div className="track-legend"><small><i style={{background:"#d4a44e"}}/> Sunlight estimate</small><small><i style={{background:"#233d50"}}/> Reduced illumination</small><small><i style={{background:"#58cddd"}}/> Selected time</small></div></section>
    <section className="panel compare-panel"><div className="timeline-head"><h3>QUICK SITE COMPARISON</h3><span>RELATIVE INDICES</span></div><div className="compare-cards">{sites.filter((_,i)=>i!==siteIndex).slice(0,2).map(s=><div className="compare-card" key={s.name}><small>{s.region}</small><strong>{s.name}</strong><span>☀ {s.sunlight}% &nbsp; ◉ {s.earth}% Earth visibility</span></div>)}</div></section>
   </div>
   <div className="footer"><span><b>LUNAR VISION</b> · MISSION INTELLIGENCE PLATFORM</span><span>DEMO DATA · NOT FOR FLIGHT OPERATIONS</span><span>BUILD 0.1.0</span></div>
  </main>
 </div>
}
