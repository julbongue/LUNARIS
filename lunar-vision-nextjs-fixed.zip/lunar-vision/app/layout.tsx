import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "Lunar Vision | Mission Control", description: "Interactive lunar landing site analysis" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt"><body>{children}</body></html>; }
